export interface Product {
  id: number;
  seller_id?: number;
  name_pt: string;
  name_ch?: string;
  name_mc?: string;
  description_pt: string;
  price: number;
  image_url: string;
  category: string;
  stock: number;
  is_special_offer?: boolean;
  condition?: 'new' | 'used';
  brand?: string;
  seller_phone?: string;
  seller_name?: string;
  created_at?: string;
}

export interface Region {
  id: number;
  name: string;
  shipping_fee: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: number;
  customer_name: string;
  customer_phone: string;
  region_id: number;
  address: string;
  total_amount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  created_at: string;
  items?: any[];
}

export type Language = 'pt' | 'ch' | 'mc';

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'seller' | 'buyer';
  phone?: string;
  wallet_balance?: number;
  loyalty_points?: number;
}

export interface Review {
  id: number;
  product_id: number;
  user_name: string;
  rating: number;
  comment: string;
  image_url?: string;
  created_at: string;
}

export interface Seller {
  id: number;
  user_id: number;
  name: string;
  email: string;
  phone: string;
  business_name: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

export interface Message {
  id: number;
  order_id: number;
  sender: 'customer' | 'seller';
  text: string;
  created_at: string;
}

export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}

export interface PayoutRequest {
  id: number;
  seller_id: number;
  amount: number;
  method: string;
  status: 'pending' | 'completed' | 'rejected';
  created_at: string;
}

export const PRODUCT_CATEGORIES = [
  "Eletrônicos e Tecnologia",
  "Smartphones, tablets, laptops",
  "TVs, câmeras, acessórios",
  "Gadgets e dispositivos inteligentes",
  "Moda e Acessórios",
  "Roupas masculinas, femininas e infantis",
  "Calçados",
  "Bolsas, joias e relógios",
  "Casa e Decoração",
  "Móveis",
  "Iluminação",
  "Artigos de cama, mesa e banho",
  "Alimentos e Bebidas",
  "Mercearia",
  "Bebidas alcoólicas e não alcoólicas",
  "Produtos gourmet e saudáveis",
  "Beleza e Cuidados Pessoais",
  "Cosméticos e maquiagem",
  "Perfumes",
  "Produtos de higiene e cuidados com a pele",
  "Esporte e Lazer",
  "Equipamentos esportivos",
  "Roupas fitness",
  "Bicicletas e acessórios",
  "Brinquedos e Jogos",
  "Brinquedos educativos",
  "Jogos de tabuleiro",
  "Videogames e consoles",
  "Automotivo",
  "Peças e acessórios",
  "Ferramentas para manutenção",
  "Produtos de limpeza automotiva",
  "Livros, Música e Papelaria",
  "Livros físicos e digitais",
  "Instrumentos musicais",
  "Material escolar e escritório",
  "Saúde e Bem-estar",
  "Suplementos",
  "Produtos naturais",
  "Equipamentos médicos domésticos"
];

export const translations = {
  pt: {
    welcome: "Bem-vindo à TomiraShop",
    catalog: "Catálogo",
    cart: "Carrinho",
    checkout: "Finalizar Compra",
    tracking: "Rastrear Pedido",
    admin: "Painel Admin",
    add_to_cart: "Adicionar ao Carrinho",
    price: "Preço",
    shipping: "Frete",
    total: "Total",
    name: "Nome",
    phone: "Telefone",
    address: "Endereço",
    region: "Região",
    place_order: "Fazer Pedido",
    order_status: "Status do Pedido",
    empty_cart: "Seu carrinho está vazio",
    m_pesa_instruction: 'Pague via M-Pesa para o número 848831383 (Tonilde Mussa). Use o ID do pedido como referência.',
    e_mola_instruction: 'Pague via e-Mola para o número 878831383 (Tonilde Mussa). Use o ID do pedido como referência.',
    login: 'Entrar',
    register: 'Criar Conta',
    logout: 'Sair',
    wishlist: 'Lista de Desejos',
    reviews: 'Avaliações',
    add_review: 'Avaliar Produto',
    my_orders: 'Meus Pedidos',
    guest_checkout: 'Compra Directa',
    flash_deals: 'Ofertas Relâmpago',
    recommended: 'Recomendados para Você',
    payment_method: 'Método de Pagamento',
    seller_dashboard: 'Painel do Vendedor',
    my_products: 'Meus Produtos',
    add_product: 'Adicionar Produto',
    edit_product: 'Editar Produto',
    performance: 'Desempenho',
    sales: 'Vendas',
    revenue: 'Receita',
    chatbot_title: 'Assistente Tomira',
    chatbot_placeholder: 'Como posso ajudar?',
    special_offer: 'Oferta Especial',
    manual_category: 'Outra Categoria',
    contact_seller: "Contactar Vendedor",
    contact_support: "Suporte WhatsApp",
    whatsapp_message_product: "Olá! Tenho interesse no produto: ",
    whatsapp_message_order: "Olá! Gostaria de informações sobre o meu pedido: ",
    whatsapp_message_admin: "Olá! Sou um vendedor da TomiraShop e preciso de suporte.",
    wallet: "Carteira",
    balance: "Saldo Disponível",
    loyalty_points: "Pontos Tomira",
    analytics: "Análises",
    payout: "Levantamento",
    notifications: "Notificações",
    condition: "Condição",
    new: "Novo",
    used: "Usado",
    brand: "Marca",
    dark_mode: "Modo Escuro",
    light_mode: "Modo Claro",
    pending: "Pendente",
    processing: "Processando",
    shipped: "Enviado",
    delivered: "Entregue",
    cancelled: "Cancelado",
  },
  ch: {
    welcome: "Amukelini ka TomiraShop",
    catalog: "Xitolo",
    cart: "Xirundzu",
    checkout: "Ku hakhela",
    tracking: "Ku landzelela",
    admin: "Admin",
    add_to_cart: "Chela ka xirundzu",
    price: "Nxavo",
    shipping: "Frete",
    total: "Hinkwaswo",
    name: "Vito",
    phone: "Foni",
    address: "Endereço",
    region: "Region",
    place_order: "Yendla pedido",
    order_status: "Status",
    empty_cart: "Xirundzu xi hava nchumu",
    m_pesa_instruction: "Hakhela hi M-Pesa ka 84XXXXXXX",
    pending: "Ku rindzela",
    processing: "Ku yendliwa",
    shipped: "Ku rhumeriwa",
    delivered: "Ku fika",
    cancelled: "Ku yimisiwa",
  },
  mc: {
    welcome: "Mwakhuweliwa TomiraShop",
    catalog: "Eshitoro",
    cart: "Eshirundzu",
    checkout: "Olipha",
    tracking: "Othara",
    admin: "Admin",
    add_to_cart: "Ohela mushirundzu",
    price: "Musika",
    shipping: "Frete",
    total: "Otheene",
    name: "Nsina",
    phone: "Foni",
    address: "Endereço",
    region: "Region",
    place_order: "Opaka pedido",
    order_status: "Status",
    empty_cart: "Eshirundzu khirina echu",
    m_pesa_instruction: "Olipha ni M-Pesa 84XXXXXXX",
    pending: "Onwehererya",
    processing: "Opakiwa",
    shipped: "Orumiwa",
    delivered: "Ofiya",
    cancelled: "Ohiyeryiwa",
  }
};
