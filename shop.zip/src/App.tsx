import React, { useState, useEffect, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useParams } from 'react-router-dom';
import { 
  ShoppingBag, ShoppingCart, MapPin, Package, Settings, ChevronRight, Plus, Minus, X, Languages,
  Truck, CreditCard, Phone, Search, MessageCircle, UserPlus, Send, MessageSquare, AlertCircle,
  MessageCircleMore, Heart, Star, User as UserIcon, LayoutDashboard, BarChart3, TrendingUp,
  DollarSign, Edit, Trash2, Sparkles, Bell, Wallet, Sun, Moon, ArrowUpRight, ArrowDownRight,
  PieChart as PieChartIcon, Clock, Bot, ArrowRight
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, PieChart, Cell, BarChart, Bar
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster, toast } from 'react-hot-toast';
import { io } from 'socket.io-client';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { GoogleGenAI } from "@google/genai";
import { 
  Product, 
  Region, 
  CartItem, 
  Order, 
  Language, 
  translations, 
  User,
  Notification,
  PayoutRequest,
  PRODUCT_CATEGORIES
} from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const socket = io();

export default function App() {
  const [language, setLanguage] = useState<Language>('pt');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (user) {
      // Refresh user data to get wallet and points
      window.fetch(`/api/auth/me/${user.id}`)
        .then(res => res.json())
        .then(data => {
          if (data.success) setUser(data.user);
        });

      // Fetch notifications
      window.fetch(`/api/notifications/${user.id}`)
        .then(res => res.json())
        .then(setNotifications);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
      window.fetch(`/api/wishlist/${user.id}`)
        .then(res => res.json())
        .then(data => setWishlist(data.map((p: any) => p.id)));
    } else {
      localStorage.removeItem('user');
      setWishlist([]);
    }
  }, [user]);

  const t = translations[language];

  useEffect(() => {
    window.fetch('/api/regions').then(res => res.json()).then(setRegions);
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      window.fetch(`/api/products?search=${searchQuery}`).then(res => res.json()).then(setProducts);
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    toast.success(t.add_to_cart);
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const toggleWishlist = async (productId: number) => {
    if (!user) {
      setAuthMode('login');
      setShowAuthModal(true);
      return;
    }

    const isWishlisted = wishlist.includes(productId);
    if (isWishlisted) {
      await window.fetch(`/api/wishlist/${user.id}/${productId}`, { method: 'DELETE' });
      setWishlist(prev => prev.filter(id => id !== productId));
      toast.success('Removido da lista de desejos');
    } else {
      await window.fetch('/api/wishlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, productId })
      });
      setWishlist(prev => [...prev, productId]);
      toast.success('Adicionado à lista de desejos');
    }
  };

  const handleLogin = async (e: React.FormEvent, credentials: any) => {
    e.preventDefault();
    try {
      const res = await window.fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        setShowAuthModal(false);
        toast.success(`Bem-vindo, ${data.user.name}!`);
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      toast.error('Erro ao entrar.');
    }
  };

  const handleRegister = async (e: React.FormEvent, data: any) => {
    e.preventDefault();
    try {
      const res = await window.fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const resData = await res.json();
      if (resData.success) {
        setUser(resData.user);
        setShowAuthModal(false);
        toast.success('Conta criada com sucesso!');
      } else {
        toast.error(resData.error);
      }
    } catch (error) {
      toast.error('Erro ao criar conta.');
    }
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = useMemo(() => cart.reduce((acc, item) => acc + (item.price * item.quantity), 0), [cart]);

  return (
    <Router>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 transition-colors duration-300">
        <Toaster position="top-center" />
        
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20">
                <ShoppingBag size={24} />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-800 dark:text-white">TomiraShop</span>
            </Link>

            <div className="flex-1 max-w-md mx-8 hidden md:block">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  placeholder="Procurar produtos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-white"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-4">
              {/* Dark Mode Toggle */}
              <button 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-600 dark:text-slate-400"
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>

              {/* Notifications */}
              {user && (
                <div className="relative">
                  <button 
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-600 dark:text-slate-400"
                  >
                    <Bell size={20} />
                    {notifications.filter(n => !n.is_read).length > 0 && (
                      <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-slate-900" />
                    )}
                  </button>
                  <AnimatePresence>
                    {showNotifications && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl z-50 overflow-hidden"
                      >
                        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                          <h3 className="font-bold">{t.notifications}</h3>
                          <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
                        </div>
                        <div className="max-h-96 overflow-y-auto">
                          {notifications.length === 0 ? (
                            <div className="p-8 text-center text-slate-400 text-sm">Nenhuma notificação</div>
                          ) : (
                            notifications.map(n => (
                              <div key={n.id} className={cn("p-4 border-b border-slate-50 dark:border-slate-800 last:border-0", !n.is_read && "bg-emerald-50/50 dark:bg-emerald-900/10")}>
                                <h4 className="text-sm font-bold">{n.title}</h4>
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{n.message}</p>
                                <p className="text-[10px] text-slate-400 mt-2">{new Date(n.created_at).toLocaleString()}</p>
                              </div>
                            ))
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}

              <div className="relative group">
                <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors flex items-center gap-1">
                  <Languages size={20} className="text-slate-600 dark:text-slate-400" />
                  <span className="text-xs font-semibold uppercase dark:text-slate-400">{language}</span>
                </button>
                <div className="absolute right-0 mt-2 w-32 bg-white border border-slate-200 rounded-xl shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all transform translate-y-2 group-hover:translate-y-0 z-50">
                  {(['pt', 'ch', 'mc'] as Language[]).map(lang => (
                    <button
                      key={lang}
                      onClick={() => setLanguage(lang)}
                      className={cn(
                        "w-full text-left px-4 py-2 text-sm first:rounded-t-xl last:rounded-b-xl hover:bg-slate-50 transition-colors",
                        language === lang && "text-emerald-600 font-bold bg-emerald-50"
                      )}
                    >
                      {lang === 'pt' ? 'Português' : lang === 'ch' ? 'Changana' : 'Macua'}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
              >
                <ShoppingCart size={22} className="text-slate-600 dark:text-slate-400" />
                {cart.length > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-emerald-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900">
                    {cart.reduce((a, b) => a + b.quantity, 0)}
                  </span>
                )}
              </button>

              {user ? (
                <div className="relative group">
                  <button className="flex items-center gap-2 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
                    <div className="w-8 h-8 bg-slate-900 dark:bg-emerald-600 text-white rounded-lg flex items-center justify-center text-xs font-bold">
                      {user.name.charAt(0)}
                    </div>
                    <div className="hidden sm:flex flex-col items-start leading-none">
                      <span className="text-sm font-bold">{user.name.split(' ')[0]}</span>
                      <span className="text-[10px] text-emerald-600 font-black uppercase mt-0.5">{user.loyalty_points || 0} pts</span>
                    </div>
                  </button>
                  <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all transform translate-y-2 group-hover:translate-y-0 z-50 p-2">
                    <div className="px-3 py-3 border-b border-slate-100 dark:border-slate-800 mb-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Carteira</p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-black text-emerald-600">{(user.wallet_balance || 0).toLocaleString()} MT</span>
                        <Wallet size={14} className="text-slate-300" />
                      </div>
                    </div>
                    <button className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2">
                      <Package size={16} /> {t.my_orders}
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2">
                      <Heart size={16} /> {t.wishlist}
                    </button>
                    {user.role === 'seller' && (
                      <Link to="/seller-dashboard" className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2">
                        <LayoutDashboard size={16} /> {t.seller_dashboard}
                      </Link>
                    )}
                    {user.role === 'admin' && (
                      <Link to="/admin" className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2">
                        <Settings size={16} /> {t.admin}
                      </Link>
                    )}
                    <button 
                      onClick={() => setUser(null)}
                      className="w-full text-left px-3 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors flex items-center gap-2 mt-1"
                    >
                      <X size={16} /> {t.logout}
                    </button>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-slate-800 dark:hover:bg-emerald-700 transition-all active:scale-95"
                >
                  <UserIcon size={18} />
                  <span className="hidden sm:block">{t.login}</span>
                </button>
              )}
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Catalog products={products} addToCart={addToCart} language={language} t={t} toggleWishlist={toggleWishlist} wishlist={wishlist} />} />
            <Route path="/checkout" element={<Checkout cart={cart} regions={regions} cartTotal={cartTotal} t={t} setCart={setCart} user={user} />} />
            <Route path="/tracking/:id" element={<Tracking t={t} />} />
            <Route path="/admin" element={<AdminPanel t={t} />} />
            <Route path="/seller-register" element={<SellerRegister t={t} />} />
            <Route path="/seller-dashboard" element={<SellerDashboard t={t} user={user} />} />
          </Routes>
        </main>

        {/* Floating Chatbot Toggle */}
        <button 
          onClick={() => setIsChatbotOpen(true)}
          className="fixed bottom-6 right-6 w-14 h-14 bg-emerald-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-emerald-700 transition-all active:scale-95 z-40 group"
        >
          <Bot size={28} />
          <span className="absolute right-full mr-4 px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            {t.chatbot_title}
          </span>
        </button>

        <AnimatePresence>
          {isChatbotOpen && (
            <Chatbot onClose={() => setIsChatbotOpen(false)} t={t} user={user} />
          )}
        </AnimatePresence>

        {/* Footer */}
        <footer className="bg-slate-900 text-slate-300 py-12 mt-20">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-white">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <ShoppingBag size={18} />
                </div>
                <span className="text-xl font-bold">TomiraShop</span>
              </div>
              <p className="text-sm opacity-70">
                Bobre - Criado por TonnyService<br />
                Tonilde Mussa, Engenheiro de Redes, trabalhador, empreendedor, casado
              </p>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-white font-bold uppercase text-xs tracking-widest">Contactos</h4>
              <div className="space-y-2 text-sm">
                <p className="flex items-center gap-2"><Phone size={14} /> Tonilde Mussa: 878831383 / 848831383</p>
                <a 
                  href="https://wa.me/258848831383" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="flex items-center gap-2 hover:text-emerald-400 transition-colors"
                >
                  <MessageCircle size={14} /> Whatsapp: 848831383
                </a>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-bold uppercase text-xs tracking-widest">Links Úteis</h4>
              <div className="flex flex-col gap-2 text-sm">
                <Link to="/seller-register" className="hover:text-emerald-400 transition-colors">Seja um Vendedor</Link>
                <button className="text-left hover:text-emerald-400 transition-colors">Reclamações</button>
              </div>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-slate-800 text-center text-xs opacity-50">
            &copy; {new Date().getFullYear()} TomiraShop. Todos os direitos reservados.
          </div>
        </footer>

        {/* Cart Drawer */}
        <AnimatePresence>
          {isCartOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsCartOpen(false)}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
              />
              <motion.div 
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-50 shadow-2xl flex flex-col"
              >
                <div className="p-6 border-bottom border-slate-100 flex items-center justify-between">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <ShoppingCart size={24} className="text-emerald-600" />
                    {t.cart}
                  </h2>
                  <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X size={24} />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                      <ShoppingBag size={64} strokeWidth={1} />
                      <p>{t.empty_cart}</p>
                    </div>
                  ) : (
                    cart.map(item => (
                      <div key={item.id} className="flex gap-4">
                        <img src={item.image_url} alt={item.name_pt} className="w-20 h-20 object-cover rounded-xl shadow-sm" />
                        <div className="flex-1">
                          <h3 className="font-semibold text-slate-800">{language === 'pt' ? item.name_pt : language === 'ch' ? item.name_ch || item.name_pt : item.name_mc || item.name_pt}</h3>
                          <p className="text-emerald-600 font-bold text-sm">{item.price.toLocaleString()} MT</p>
                          <div className="flex items-center gap-3 mt-2">
                            <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"><Minus size={14} /></button>
                            <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"><Plus size={14} /></button>
                            <button onClick={() => removeFromCart(item.id)} className="ml-auto text-red-500 hover:text-red-600 p-1"><X size={18} /></button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="p-6 bg-slate-50 border-t border-slate-100 space-y-4">
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>{t.total}</span>
                      <span className="text-emerald-600">{cartTotal.toLocaleString()} MT</span>
                    </div>
                    <Link 
                      to="/checkout" 
                      onClick={() => setIsCartOpen(false)}
                      className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
                    >
                      {t.checkout}
                      <ChevronRight size={20} />
                    </Link>
                  </div>
                )}
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </Router>
  );
}

// --- Components ---

function Catalog({ products, addToCart, language, t, toggleWishlist, wishlist }: { products: Product[], addToCart: (p: Product) => void, language: Language, t: any, toggleWishlist: (id: number) => void, wishlist: number[] }) {
  const flashDeals = useMemo(() => products.slice(0, 2), [products]);
  const recommended = useMemo(() => products.slice(2, 6), [products]);
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const [condition, setCondition] = useState<'all' | 'new' | 'used'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc'>('newest');

  const filteredProducts = useMemo(() => {
    let result = products;
    if (activeCategory !== 'Todos') {
      result = result.filter(p => p.category === activeCategory);
    }
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (condition !== 'all') {
      result = result.filter(p => p.condition === condition);
    }
    
    if (sortBy === 'price_asc') result = [...result].sort((a, b) => a.price - b.price);
    if (sortBy === 'price_desc') result = [...result].sort((a, b) => b.price - a.price);
    if (sortBy === 'newest') result = [...result].sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());
    
    return result;
  }, [products, activeCategory, priceRange, condition, sortBy]);

  return (
    <div className="space-y-12">
      {/* Floating Category Menu */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-30 hidden xl:flex flex-col gap-2 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-3 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-2xl">
        {['Todos', 'Alimentos e Bebidas', 'Eletrônicos e Tecnologia', 'Moda e Acessórios', 'Casa e Decoração'].map(cat => (
          <button 
            key={cat} 
            onClick={() => setActiveCategory(cat)}
            className={cn(
              "p-3 rounded-2xl transition-all group relative",
              activeCategory === cat ? "bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/40" : "text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
          >
            {cat === 'Todos' ? <LayoutDashboard size={20} /> : cat === 'Alimentos e Bebidas' ? <ShoppingBag size={20} /> : cat === 'Eletrônicos e Tecnologia' ? <TrendingUp size={20} /> : cat === 'Moda e Acessórios' ? <UserIcon size={20} /> : <MapPin size={20} />}
            <span className="absolute left-full ml-4 px-2 py-1 bg-slate-900 text-white text-[10px] font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
              {cat}
            </span>
          </button>
        ))}
      </div>

      {/* Filters Bar */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-wrap items-center gap-6">
        <div className="flex-1 min-w-[200px] space-y-2">
          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Preço Máximo: {priceRange[1].toLocaleString()} MT</label>
          <input 
            type="range" min="0" max="100000" step="1000" 
            value={priceRange[1]} onChange={e => setPriceRange([0, Number(e.target.value)])}
            className="w-full accent-emerald-600"
          />
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setCondition('all')}
            className={cn("px-4 py-2 rounded-xl text-xs font-bold transition-all", condition === 'all' ? "bg-emerald-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500")}
          >Todos</button>
          <button 
            onClick={() => setCondition('new')}
            className={cn("px-4 py-2 rounded-xl text-xs font-bold transition-all", condition === 'new' ? "bg-emerald-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500")}
          >{t.new}</button>
          <button 
            onClick={() => setCondition('used')}
            className={cn("px-4 py-2 rounded-xl text-xs font-bold transition-all", condition === 'used' ? "bg-emerald-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500")}
          >{t.used}</button>
        </div>
        <select 
          value={sortBy} onChange={e => setSortBy(e.target.value as any)}
          className="bg-slate-100 dark:bg-slate-800 border-none rounded-xl px-4 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500"
        >
          <option value="newest">Mais Recentes</option>
          <option value="price_asc">Menor Preço</option>
          <option value="price_desc">Maior Preço</option>
        </select>
      </div>

      {/* Hero / Flash Deals */}
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative overflow-hidden rounded-[2.5rem] bg-emerald-900 text-white p-8 md:p-16"
      >
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <motion.div 
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-800/50 border border-emerald-700/50 text-xs font-bold uppercase tracking-widest"
            >
              <Sparkles size={14} className="text-emerald-400" />
              {t.flash_deals}
            </motion.div>
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-5xl md:text-7xl font-black leading-tight tracking-tighter"
            >
              TomiraShop <br />
              <span className="text-emerald-400">Nampula</span> para o Mundo
            </motion.h1>
            <motion.p 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-emerald-100/70 text-xl max-w-lg leading-relaxed"
            >
              A maior plataforma de e-commerce de Moçambique. Qualidade, confiança e entrega nacional.
            </motion.p>
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex items-center gap-4"
            >
              <button className="bg-white text-emerald-900 px-10 py-5 rounded-2xl font-black shadow-2xl shadow-black/20 hover:bg-emerald-50 transition-all active:scale-95 flex items-center gap-2">
                Explorar Agora
                <ArrowRight size={20} />
              </button>
            </motion.div>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {flashDeals.map((product, idx) => (
              <motion.div 
                key={product.id} 
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 + (idx * 0.1) }}
                className="bg-white/10 backdrop-blur-xl rounded-[2rem] p-6 border border-white/10 group cursor-pointer hover:bg-white/20 transition-all" 
                onClick={() => addToCart(product)}
              >
                <div className="relative mb-4">
                  <img src={product.image_url} alt={product.name_pt} className="w-full aspect-square object-cover rounded-2xl group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-[10px] font-black px-2 py-1 rounded-lg shadow-lg">
                    -{Math.floor(Math.random() * 20 + 10)}%
                  </div>
                </div>
                <div className="font-bold truncate text-lg">{product.name_pt}</div>
                <div className="text-emerald-400 font-black text-xl">{product.price.toLocaleString()} MT</div>
              </motion.div>
            ))}
          </div>
        </div>
        {/* Animated Orbs */}
        <div className="absolute -top-24 -right-24 w-[30rem] h-[30rem] bg-emerald-500/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute -bottom-24 -left-24 w-[30rem] h-[30rem] bg-emerald-400/10 rounded-full blur-[100px] animate-pulse" />
      </motion.section>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black tracking-tight text-slate-900">{t.catalog}</h2>
          <p className="mt-2 text-slate-500">Filtrando por: <span className="font-bold text-emerald-600">{activeCategory}</span></p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {['Todos', 'Alimentos e Bebidas', 'Eletrônicos e Tecnologia', 'Moda e Acessórios'].map(cat => (
            <button 
              key={cat} 
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "px-6 py-3 rounded-2xl text-sm font-bold whitespace-nowrap transition-all",
                activeCategory === cat ? "bg-slate-900 text-white shadow-xl" : "bg-white border border-slate-200 text-slate-500 hover:border-emerald-500 hover:text-emerald-600"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredProducts.map(product => (
            <motion.div 
              key={product.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="group bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <img 
                  src={product.image_url} 
                  alt={product.name_pt} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <div className="bg-emerald-600/90 backdrop-blur text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-1.5">
                    <MapPin size={12} />
                    Envio Nacional
                  </div>
                  {product.condition && (
                    <div className={cn(
                      "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg self-start",
                      product.condition === 'new' ? "bg-blue-600 text-white" : "bg-slate-700 text-white"
                    )}>
                      {t[product.condition]}
                    </div>
                  )}
                </div>
                <div className="absolute top-4 right-4 flex flex-col gap-2">
                  <button 
                    onClick={(e) => { e.preventDefault(); toggleWishlist(product.id); }}
                    className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center shadow-2xl transition-all active:scale-90",
                      wishlist.includes(product.id) ? "bg-red-500 text-white" : "bg-white/90 backdrop-blur text-slate-400 hover:text-red-500"
                    )}
                  >
                    <Heart size={22} fill={wishlist.includes(product.id) ? "currentColor" : "none"} />
                  </button>
                  {product.is_special_offer && (
                    <div className="bg-amber-400 text-amber-900 px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-1">
                      <Sparkles size={10} />
                      {t.special_offer}
                    </div>
                  )}
                </div>
                <div className="absolute bottom-4 left-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  <button 
                    onClick={() => addToCart(product)}
                    className="w-full bg-white text-slate-900 py-4 rounded-2xl font-black shadow-xl hover:bg-emerald-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <Plus size={20} />
                    {t.add_to_cart}
                  </button>
                </div>
              </div>
              <div className="p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-[10px] font-black uppercase tracking-widest text-emerald-600">{product.category}</div>
                  {product.brand && <div className="text-[10px] font-bold text-slate-400 uppercase">{product.brand}</div>}
                </div>
                <h3 className="font-bold text-xl text-slate-800 dark:text-white line-clamp-1">
                  {language === 'pt' ? product.name_pt : language === 'ch' ? product.name_ch || product.name_pt : product.name_mc || product.name_pt}
                </h3>
                <div className="flex items-center justify-between pt-2">
                  <span className="text-2xl font-black text-slate-900 dark:text-white">{product.price.toLocaleString()} MT</span>
                  <div className="flex items-center gap-2">
                    {product.seller_phone && (
                      <a 
                        href={`https://wa.me/258${product.seller_phone.replace(/\D/g, '')}?text=${encodeURIComponent(t.whatsapp_message_product + product.name_pt)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-100 transition-colors"
                        title={t.contact_seller}
                      >
                        <MessageCircle size={18} />
                      </a>
                    )}
                    <div className="flex items-center gap-1">
                      <Star size={14} className="fill-amber-400 text-amber-400" />
                      <span className="text-sm font-bold text-slate-400">4.8</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Recommended Section */}
      <section className="space-y-8 pt-12">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-black flex items-center gap-3">
            <Star className="text-amber-400 fill-amber-400" size={32} />
            {t.recommended}
          </h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {recommended.map(product => (
            <motion.div 
              whileHover={{ y: -10 }}
              key={product.id} 
              className="bg-white dark:bg-slate-900 p-5 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all cursor-pointer group" 
              onClick={() => addToCart(product)}
            >
              <div className="relative mb-4 overflow-hidden rounded-2xl">
                <img src={product.image_url} alt={product.name_pt} className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div className="font-bold text-slate-800 dark:text-white truncate text-lg">{product.name_pt}</div>
              <div className="text-emerald-600 font-black text-xl mt-1">{product.price.toLocaleString()} MT</div>
              <div className="flex items-center gap-1 mt-3">
                {[1,2,3,4,5].map(s => <Star key={s} size={12} className="fill-amber-400 text-amber-400" />)}
                <span className="text-xs font-bold text-slate-400 ml-2">(128)</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Checkout({ cart, regions, cartTotal, t, setCart, user }: { cart: CartItem[], regions: Region[], cartTotal: number, t: any, setCart: any, user: User | null }) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    customer_name: user?.name || '',
    customer_phone: user?.phone || '',
    region_id: '',
    address: ''
  });
  const [paymentMethod, setPaymentMethod] = useState<'mpesa' | 'emola'>('mpesa');
  const [negotiationDiscount, setNegotiationDiscount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedRegion = regions.find(r => r.id === Number(formData.region_id));
  const shippingFee = selectedRegion?.shipping_fee || 0;
  
  // Negotiation logic: max 100MT discount if within city (simplified as any region for now, but capped at 100)
  const handleDiscountChange = (val: string) => {
    const num = parseInt(val) || 0;
    if (num <= 100) setNegotiationDiscount(num);
    else toast.error("Ajuste máximo permitido é de 100 MT");
  };

  const finalTotal = cartTotal + shippingFee - negotiationDiscount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    
    setIsSubmitting(true);
    try {
      const res = await window.fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          items: cart,
          total_amount: finalTotal
        })
      });
      const data = await res.json();
      if (data.success) {
        toast.success('Pedido realizado com sucesso!');
        setCart([]);
        navigate(`/tracking/${data.orderId}`);
      }
    } catch (error) {
      toast.error('Erro ao realizar pedido.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 flex items-center gap-3">
        <CreditCard className="text-emerald-600" />
        {t.checkout}
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <MapPin size={20} className="text-emerald-600" />
              Informações de Entrega
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">{t.name}</label>
                <input 
                  required
                  type="text" 
                  value={formData.customer_name}
                  onChange={e => setFormData({...formData, customer_name: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="Seu nome completo"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">{t.phone}</label>
                <div className="relative">
                  <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    required
                    type="tel" 
                    value={formData.customer_phone}
                    onChange={e => setFormData({...formData, customer_phone: e.target.value})}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="84XXXXXXX"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">{t.region}</label>
                <select 
                  required
                  value={formData.region_id}
                  onChange={e => setFormData({...formData, region_id: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all appearance-none bg-white"
                >
                  <option value="">Selecione sua província</option>
                  {regions.map(r => (
                    <option key={r.id} value={r.id}>{r.name} (+{r.shipping_fee} MT)</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">{t.address}</label>
                <textarea 
                  required
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all h-24"
                  placeholder="Bairro, Quarteirão, Casa nº..."
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Ajuste de Preço (Negociação - Max 100 MT)</label>
                <div className="relative">
                  <input 
                    type="number" 
                    max="100"
                    value={negotiationDiscount}
                    onChange={e => handleDiscountChange(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    placeholder="Valor a descontar (0-100)"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">MT</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">* Válido para negociações dentro da cidade.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <CreditCard size={20} className="text-emerald-600" />
              {t.payment_method}
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <button 
                type="button"
                onClick={() => setPaymentMethod('mpesa')}
                className={cn(
                  "p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2",
                  paymentMethod === 'mpesa' ? "border-red-500 bg-red-50" : "border-slate-100 hover:border-slate-200"
                )}
              >
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white font-black">M</div>
                <span className="font-bold">M-Pesa</span>
              </button>
              <button 
                type="button"
                onClick={() => setPaymentMethod('emola')}
                className={cn(
                  "p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2",
                  paymentMethod === 'emola' ? "border-orange-500 bg-orange-50" : "border-slate-100 hover:border-slate-200"
                )}
              >
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-black">E</div>
                <span className="font-bold">e-Mola</span>
              </button>
            </div>

            <div className={cn(
              "p-6 rounded-3xl border",
              paymentMethod === 'mpesa' ? "bg-red-50 border-red-100 text-red-800" : "bg-orange-50 border-orange-100 text-orange-800"
            )}>
              <h3 className="font-bold flex items-center gap-2 mb-2">
                <AlertCircle size={18} />
                Instruções
              </h3>
              <p className="text-sm">
                {paymentMethod === 'mpesa' ? t.m_pesa_instruction : t.e_mola_instruction}
              </p>
            </div>
          </div>

          <button 
            disabled={isSubmitting || cart.length === 0}
            type="submit"
            className="w-full bg-slate-900 text-white py-5 rounded-3xl font-bold text-lg shadow-xl shadow-slate-200 hover:bg-emerald-600 transition-all active:scale-95 disabled:opacity-50"
          >
            {isSubmitting ? 'Processando...' : t.place_order}
          </button>
        </form>

        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h2 className="text-xl font-bold mb-6">Resumo do Pedido</h2>
            <div className="space-y-4 mb-6">
              {cart.map(item => (
                <div key={item.id} className="flex justify-between items-center">
                  <span className="text-slate-600">{item.quantity}x {item.name_pt}</span>
                  <span className="font-semibold">{(item.price * item.quantity).toLocaleString()} MT</span>
                </div>
              ))}
            </div>
            <div className="border-t border-slate-100 pt-6 space-y-3">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span>{cartTotal.toLocaleString()} MT</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>{t.shipping}</span>
                <span>{shippingFee.toLocaleString()} MT</span>
              </div>
              {negotiationDiscount > 0 && (
                <div className="flex justify-between text-red-500">
                  <span>Desconto (Negociação)</span>
                  <span>-{negotiationDiscount.toLocaleString()} MT</span>
                </div>
              )}
              <div className="flex justify-between text-xl font-black text-emerald-600 pt-2">
                <span>{t.total}</span>
                <span>{finalTotal.toLocaleString()} MT</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Tracking({ t }: { t: any }) {
  const { id } = useParams();
  const [order, setOrder] = useState<Order | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const orderId = id;

  useEffect(() => {
    const loadOrder = async () => {
      const res = await window.fetch(`/api/orders/${orderId}`);
      const data = await res.json();
      setOrder(data);
    };
    const loadMessages = async () => {
      const res = await window.fetch(`/api/orders/${orderId}/messages`);
      const data = await res.json();
      setMessages(data);
    };
    loadOrder();
    loadMessages();

    socket.on(`order_update_${orderId}`, (data) => {
      setOrder(prev => prev ? { ...prev, status: data.status } : null);
      toast(`Status do pedido atualizado: ${t[data.status]}`, { icon: '📦' });
    });

    socket.on(`order_message_${orderId}`, (msg) => {
      setMessages(prev => [...prev, msg]);
    });

    return () => {
      socket.off(`order_update_${orderId}`);
      socket.off(`order_message_${orderId}`);
    };
  }, [orderId, t]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    await window.fetch(`/api/orders/${orderId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender: 'customer', text: newMessage })
    });
    setNewMessage('');
  };

  if (!order) return <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-12 w-12 border-4 border-emerald-600 border-t-transparent"></div></div>;

  const steps = ['pending', 'processing', 'shipped', 'delivered'];
  const currentStep = steps.indexOf(order.status);

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-8">
        <div className="text-center space-y-2">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <Truck size={40} />
          </div>
          <h1 className="text-3xl font-bold">{t.tracking}</h1>
          <p className="text-slate-500">Pedido #{order.id}</p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
          <div className="relative flex justify-between">
            <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-100 -translate-y-1/2 -z-0" />
            <div 
              className="absolute top-1/2 left-0 h-1 bg-emerald-600 -translate-y-1/2 transition-all duration-1000" 
              style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
            />
            
            {steps.map((step, idx) => (
              <div key={step} className="relative z-10 flex flex-col items-center gap-2">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-500",
                  idx <= currentStep ? "bg-emerald-600 border-emerald-100 text-white" : "bg-white border-slate-100 text-slate-300"
                )}>
                  {idx < currentStep ? <ChevronRight size={16} /> : idx + 1}
                </div>
                <span className={cn(
                  "text-[10px] font-bold uppercase tracking-wider",
                  idx <= currentStep ? "text-emerald-600" : "text-slate-400"
                )}>
                  {t[step]}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Detalhes da Entrega</h2>
            <a 
              href={`https://wa.me/258848831383?text=${encodeURIComponent(t.whatsapp_message_order + order.id)}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
            >
              <MessageCircle size={16} />
              {t.contact_support}
            </a>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase mb-1">Cliente</p>
              <p className="font-semibold">{order.customer_name}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase mb-1">Telefone</p>
              <p className="font-semibold">{order.customer_phone}</p>
            </div>
            <div className="col-span-2">
              <p className="text-xs font-bold text-slate-400 uppercase mb-1">Endereço</p>
              <p className="font-semibold">{order.address}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chatbox */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-xl flex flex-col h-[600px] overflow-hidden">
        <div className="p-4 bg-slate-900 text-white flex items-center gap-3">
          <MessageCircleMore size={20} className="text-emerald-400" />
          <div>
            <h3 className="font-bold text-sm">Chat com Fornecedor</h3>
            <p className="text-[10px] opacity-60">Negocie seu pedido aqui</p>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
          {messages.map(msg => (
            <div key={msg.id} className={cn(
              "max-w-[80%] p-3 rounded-2xl text-sm shadow-sm",
              msg.sender === 'customer' 
                ? "ml-auto bg-emerald-600 text-white rounded-tr-none" 
                : "mr-auto bg-white text-slate-800 rounded-tl-none border border-slate-100"
            )}>
              {msg.text}
              <div className={cn(
                "text-[9px] mt-1 opacity-60",
                msg.sender === 'customer' ? "text-right" : "text-left"
              )}>
                {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={sendMessage} className="p-4 border-t border-slate-100 flex gap-2">
          <input 
            type="text" 
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            placeholder="Escreva uma mensagem..."
            className="flex-1 px-4 py-2 bg-slate-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
          />
          <button type="submit" className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center hover:bg-emerald-700 transition-colors">
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
}

function SellerRegister({ t }: { t: any }) {
  const [formData, setFormData] = useState({ business_name: '', category: PRODUCT_CATEGORIES[0] });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error('Por favor, faça login primeiro.');
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await window.fetch('/api/sellers/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, business_name: formData.business_name })
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
      } else {
        toast.error(data.error || 'Erro ao cadastrar.');
      }
    } catch (error) {
      toast.error('Erro ao enviar cadastro.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-12">
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden">
        <div className="bg-emerald-600 p-12 text-white text-center space-y-4">
          <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center mx-auto">
            <ShoppingBag size={40} />
          </div>
          <h1 className="text-3xl font-black">Seja um Vendedor Tomira</h1>
          <p className="opacity-80">Venda seus produtos para todo o Moçambique a partir de Nampula.</p>
        </div>
        <form onSubmit={handleSubmit} className="p-12 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Nome do Negócio</label>
              <input 
                required type="text" value={formData.business_name} onChange={e => setFormData({...formData, business_name: e.target.value})}
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="Ex: Tomira Eletrónicos"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Categoria Principal</label>
              <select 
                value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              >
                {PRODUCT_CATEGORIES.slice(0, 10).map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>
          </div>
          <button 
            disabled={isSubmitting}
            className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95 disabled:opacity-50"
          >
            {isSubmitting ? 'Enviando...' : 'Enviar Cadastro para Aprovação'}
          </button>
          <p className="text-center text-xs text-slate-400">
            Ao se cadastrar, você concorda com nossos termos de vendedor.
          </p>
        </form>
      </div>
    </div>
  );
}

function AdminPanel({ t }: { t: any }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [sellers, setSellers] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'sellers'>('orders');

  useEffect(() => {
    window.fetch('/api/admin/orders').then(res => res.json()).then(setOrders);
    window.fetch('/api/admin/sellers').then(res => res.json()).then(setSellers);
    
    socket.on('new_order', () => {
      window.fetch('/api/admin/orders').then(res => res.json()).then(setOrders);
      toast('Novo pedido recebido!', { icon: '🔔' });
    });

    return () => {
      socket.off('new_order');
    };
  }, []);

  const updateStatus = async (id: number, status: string) => {
    await window.fetch(`/api/admin/orders/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: status as any } : o));
    toast.success('Status atualizado');
  };

  const updateSellerStatus = async (id: number, status: string) => {
    await window.fetch(`/api/admin/sellers/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    setSellers(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    toast.success('Vendedor atualizado');
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Package className="text-emerald-600" />
          {t.admin}
        </h1>
        <div className="flex bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <button 
            onClick={() => setActiveTab('orders')}
            className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'orders' ? "bg-slate-900 dark:bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800")}
          >
            Pedidos
          </button>
          <button 
            onClick={() => setActiveTab('sellers')}
            className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'sellers' ? "bg-slate-900 dark:bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800")}
          >
            Vendedores
          </button>
        </div>
      </div>

      {activeTab === 'orders' ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-800">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Cliente</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Total</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-sm">#{order.id}</td>
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-800 dark:text-white">{order.customer_name}</div>
                      <div className="text-xs text-slate-500">{order.customer_phone}</div>
                    </td>
                    <td className="px-6 py-4 font-bold text-emerald-600">{order.total_amount.toLocaleString()} MT</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        order.status === 'pending' && "bg-amber-100 text-amber-700",
                        order.status === 'processing' && "bg-blue-100 text-blue-700",
                        order.status === 'shipped' && "bg-purple-100 text-purple-700",
                        order.status === 'delivered' && "bg-emerald-100 text-emerald-700",
                        order.status === 'cancelled' && "bg-red-100 text-red-700",
                      )}>
                        {t[order.status]}
                      </span>
                    </td>
                    <td className="px-6 py-4 flex gap-2">
                      <select 
                        value={order.status}
                        onChange={e => updateStatus(order.id, e.target.value)}
                        className="text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="pending">{t.pending}</option>
                        <option value="processing">{t.processing}</option>
                        <option value="shipped">{t.shipped}</option>
                        <option value="delivered">{t.delivered}</option>
                        <option value="cancelled">{t.cancelled}</option>
                      </select>
                      <Link to={`/tracking/${order.id}`} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                        <MessageSquare size={16} className="text-slate-600 dark:text-slate-400" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-800">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Vendedor</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Negócio</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {sellers.map(seller => (
                  <tr key={seller.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-800 dark:text-white">{seller.name}</div>
                      <div className="text-xs text-slate-500">{seller.email} | {seller.phone}</div>
                    </td>
                    <td className="px-6 py-4 font-medium">{seller.business_name}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        seller.status === 'pending' && "bg-amber-100 text-amber-700",
                        seller.status === 'approved' && "bg-emerald-100 text-emerald-700",
                        seller.status === 'rejected' && "bg-red-100 text-red-700",
                      )}>
                        {seller.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 flex gap-2">
                      <button onClick={() => updateSellerStatus(seller.id, 'approved')} className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-lg hover:bg-emerald-200 transition-colors">
                        Aprovar
                      </button>
                      <button onClick={() => updateSellerStatus(seller.id, 'rejected')} className="p-2 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-lg hover:bg-red-200 transition-colors">
                        Rejeitar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function SellerDashboard({ t, user }: { t: any, user: User | null }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState<Partial<Product>>({
    name_pt: '',
    description_pt: '',
    price: 0,
    image_url: '',
    category: PRODUCT_CATEGORIES[0],
    stock: 0,
    is_special_offer: false
  });
  const [manualCategory, setManualCategory] = useState('');

  const [analytics, setAnalytics] = useState<any>(null);
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);

  useEffect(() => {
    if (user) {
      window.fetch(`/api/seller/products/${user.id}`).then(res => res.json()).then(setProducts);
      window.fetch(`/api/seller/orders/${user.id}`).then(res => res.json()).then(setOrders);
      window.fetch(`/api/seller/analytics/${user.id}`).then(res => res.json()).then(setAnalytics);
      window.fetch(`/api/seller/payouts/${user.id}`).then(res => res.json()).then(setPayoutRequests);
    }
  }, [user]);

  const requestPayout = async () => {
    if (!user || (user.wallet_balance || 0) < 500) {
      toast.error('Saldo insuficiente (Mínimo 500 MT)');
      return;
    }
    const amount = prompt('Quanto deseja retirar?', user.wallet_balance?.toString());
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) return;

    const res = await window.fetch(`/api/seller/payouts/${user.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: Number(amount), method: 'M-Pesa' })
    });
    const data = await res.json();
    if (data.success) {
      toast.success('Pedido de levantamento enviado');
      window.fetch(`/api/seller/payouts/${user.id}`).then(res => res.json()).then(setPayoutRequests);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalCategory = manualCategory || formData.category;
    const payload = { ...formData, category: finalCategory, seller_id: user?.id };
    
    const url = editingProduct ? `/api/seller/products/${editingProduct.id}` : '/api/seller/products';
    const method = editingProduct ? 'PATCH' : 'POST';

    const res = await window.fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      toast.success(editingProduct ? 'Produto atualizado' : 'Produto adicionado');
      setIsAdding(false);
      setEditingProduct(null);
      window.fetch(`/api/seller/products/${user?.id}`).then(res => res.json()).then(setProducts);
    }
  };

  const deleteProduct = async (id: number) => {
    if (confirm('Tem certeza?')) {
      await window.fetch(`/api/seller/products/${id}`, { method: 'DELETE' });
      setProducts(prev => prev.filter(p => p.id !== id));
      toast.success('Produto removido');
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-black flex items-center gap-3">
            <LayoutDashboard className="text-emerald-600" />
            {t.seller_dashboard}
          </h1>
          <div className="flex items-center gap-2 text-slate-400 text-sm font-bold uppercase tracking-wider">
            <MapPin size={14} className="text-emerald-500" />
            Sede: Nampula, Moçambique
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-white dark:bg-slate-900 px-6 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Minha Carteira</p>
              <p className="text-xl font-black text-emerald-600">{(user?.wallet_balance || 0).toLocaleString()} MT</p>
            </div>
            <button 
              onClick={requestPayout}
              className="p-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20"
              title="Solicitar Levantamento"
            >
              <ArrowUpRight size={20} />
            </button>
          </div>
          <a 
            href={`https://wa.me/258848831383?text=${encodeURIComponent(t.whatsapp_message_admin)}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm"
          >
            <MessageCircle size={20} className="text-emerald-600" />
            {t.contact_support}
          </a>
          <button 
            onClick={() => { setIsAdding(true); setEditingProduct(null); }}
            className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20 hover:bg-emerald-700 transition-all"
          >
            <Plus size={20} />
            {t.add_product}
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center"><TrendingUp size={20} /></div>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t.sales}</p>
          <p className="text-3xl font-black">{orders.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex items-center justify-center"><DollarSign size={20} /></div>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t.revenue}</p>
          <p className="text-3xl font-black">{(orders.reduce((a, b) => a + b.total_amount, 0)).toLocaleString()} MT</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 text-purple-600 rounded-xl flex items-center justify-center"><Package size={20} /></div>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Produtos</p>
          <p className="text-3xl font-black">{products.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 text-amber-600 rounded-xl flex items-center justify-center"><Star size={20} /></div>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Avaliação</p>
          <p className="text-3xl font-black">4.9</p>
        </div>
      </div>

      {/* Analytics Charts */}
      {analytics && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <BarChart3 size={20} className="text-emerald-600" />
                Vendas por Dia
              </h3>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={analytics.salesByDay}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area type="monotone" dataKey="sales" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <PieChartIcon size={20} className="text-emerald-600" />
                Top Produtos
              </h3>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.topProducts} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700}} width={100} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="sales" fill="#10b981" radius={[0, 8, 8, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Product List */}
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-xl font-bold">{t.my_products}</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Produto</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Categoria</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Preço</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Stock</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {products.map(product => (
                <tr key={product.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={product.image_url} alt={product.name_pt} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="font-bold text-slate-800 dark:text-white">{product.name_pt}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">{product.category}</td>
                  <td className="px-6 py-4 font-bold text-emerald-600">{product.price.toLocaleString()} MT</td>
                  <td className="px-6 py-4 font-medium">{product.stock}</td>
                  <td className="px-6 py-4 flex gap-2">
                    <button 
                      onClick={() => { setEditingProduct(product); setFormData(product); setIsAdding(true); }}
                      className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => deleteProduct(product.id)}
                      className="p-2 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payout Requests */}
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Clock size={20} className="text-emerald-600" />
            Histórico de Levantamentos
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Data</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Valor</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Método</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {payoutRequests.length === 0 ? (
                <tr><td colSpan={4} className="px-6 py-8 text-center text-slate-400">Nenhum levantamento solicitado</td></tr>
              ) : (
                payoutRequests.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4 text-sm">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 font-bold text-emerald-600">{p.amount.toLocaleString()} MT</td>
                    <td className="px-6 py-4 text-sm">{p.method}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        p.status === 'pending' && "bg-amber-100 text-amber-700",
                        p.status === 'approved' && "bg-emerald-100 text-emerald-700",
                        p.status === 'rejected' && "bg-red-100 text-red-700",
                      )}>
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden p-8 max-h-[90vh] overflow-y-auto"
            >
              <h2 className="text-2xl font-black mb-6">{editingProduct ? t.edit_product : t.add_product}</h2>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">{t.name}</label>
                    <input 
                      required type="text" value={formData.name_pt} onChange={e => setFormData({...formData, name_pt: e.target.value})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Descrição</label>
                    <textarea 
                      required value={formData.description_pt} onChange={e => setFormData({...formData, description_pt: e.target.value})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all h-32"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Preço (MT)</label>
                    <input 
                      required type="number" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">URL da Imagem</label>
                    <input 
                      required type="text" value={formData.image_url} onChange={e => setFormData({...formData, image_url: e.target.value})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Categoria</label>
                    <select 
                      value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    >
                      {PRODUCT_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                      <option value="other">{t.manual_category}</option>
                    </select>
                  </div>
                  {formData.category === 'other' && (
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Especifique a Categoria</label>
                      <input 
                        required type="text" value={manualCategory} onChange={e => setManualCategory(e.target.value)}
                        className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      />
                    </div>
                  )}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Stock</label>
                    <input 
                      required type="number" value={formData.stock} onChange={e => setFormData({...formData, stock: Number(e.target.value)})}
                      className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-amber-50 rounded-2xl border border-amber-100">
                    <input 
                      type="checkbox" checked={formData.is_special_offer} onChange={e => setFormData({...formData, is_special_offer: e.target.checked})}
                      className="w-5 h-5 rounded border-amber-300 text-amber-600 focus:ring-amber-500"
                    />
                    <label className="text-sm font-bold text-amber-900">{t.special_offer}</label>
                  </div>
                </div>
                <div className="md:col-span-2 flex gap-4 mt-4">
                  <button type="button" onClick={() => setIsAdding(false)} className="flex-1 px-6 py-4 rounded-2xl font-bold bg-slate-100 text-slate-600 hover:bg-slate-200 transition-all">Cancelar</button>
                  <button type="submit" className="flex-1 px-6 py-4 rounded-2xl font-bold bg-emerald-600 text-white shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all">Salvar Produto</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Chatbot({ onClose, t, user }: { onClose: () => void, t: any, user: User | null }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'bot', text: string }[]>([
    { role: 'bot', text: 'Olá! Sou o assistente da TomiraShop. Como posso ajudar você hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Você é o assistente da TomiraShop, uma plataforma de e-commerce em Moçambique (Nampula). 
        Ajude o usuário com dúvidas sobre produtos, pedidos e como vender na plataforma. 
        O usuário atual é: ${user ? user.name : 'Visitante'}.
        Pergunta do usuário: ${userMsg}`,
      });

      const botText = response.text || "Desculpe, tive um problema ao processar sua solicitação.";
      setMessages(prev => [...prev, { role: 'bot', text: botText }]);
      
      // Log to DB
      window.fetch('/api/chatbot/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user?.id, message: userMsg, response: botText })
      });
    } catch (error) {
      setMessages(prev => [...prev, { role: 'bot', text: "Desculpe, estou offline no momento." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      className="fixed bottom-24 right-6 w-full max-w-sm bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 z-50 flex flex-col overflow-hidden"
    >
      <div className="p-6 bg-emerald-600 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"><Bot size={24} /></div>
          <div>
            <h3 className="font-bold">{t.chatbot_title}</h3>
            <p className="text-[10px] font-bold uppercase tracking-widest opacity-70">Online agora</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
      </div>

      <div className="flex-1 h-96 overflow-y-auto p-6 space-y-4 bg-slate-50">
        {messages.map((m, i) => (
          <div key={i} className={cn("flex", m.role === 'user' ? "justify-end" : "justify-start")}>
            <div className={cn(
              "max-w-[80%] p-4 rounded-2xl text-sm shadow-sm",
              m.role === 'user' ? "bg-emerald-600 text-white rounded-tr-none" : "bg-white text-slate-800 rounded-tl-none border border-slate-100"
            )}>
              {m.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-100 flex gap-1">
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="p-4 bg-white border-t border-slate-100 flex gap-2">
        <input 
          type="text" value={input} onChange={e => setInput(e.target.value)}
          placeholder={t.chatbot_placeholder}
          className="flex-1 px-4 py-3 rounded-xl bg-slate-100 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-sm"
        />
        <button className="p-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all">
          <Send size={20} />
        </button>
      </form>
    </motion.div>
  );
}

function AuthModal({ mode, setMode, onClose, onLogin, onRegister, t }: { mode: 'login' | 'register', setMode: (m: 'login' | 'register') => void, onClose: () => void, onLogin: any, onRegister: any, t: any }) {
  const [formData, setFormData] = useState({ name: '', email: '', password: '', phone: '' });

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        onClick={onClose} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
        className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden p-8"
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-slate-100 rounded-full transition-colors">
          <X size={24} />
        </button>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
            <UserPlus size={32} />
          </div>
          <h2 className="text-2xl font-black text-slate-900">{mode === 'login' ? t.login : t.register}</h2>
          <p className="text-slate-500 text-sm mt-1">Acesse sua conta TomiraShop</p>
        </div>

        <form onSubmit={(e) => mode === 'login' ? onLogin(e, { email: formData.email, password: formData.password }) : onRegister(e, formData)} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">{t.name}</label>
              <input 
                required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="Seu nome"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Email</label>
            <input 
              required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})}
              className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Senha</label>
            <input 
              required type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})}
              className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              placeholder="••••••••"
            />
          </div>
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">{t.phone}</label>
              <input 
                required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})}
                className="w-full px-5 py-3 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="84XXXXXXX"
              />
            </div>
          )}

          <button className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95 mt-4">
            {mode === 'login' ? t.login : t.register}
          </button>
        </form>

        <div className="mt-8 text-center text-sm">
          <span className="text-slate-500">
            {mode === 'login' ? 'Não tem uma conta?' : 'Já tem uma conta?'}
          </span>
          <button 
            onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
            className="ml-2 text-emerald-600 font-bold hover:underline"
          >
            {mode === 'login' ? t.register : t.login}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
